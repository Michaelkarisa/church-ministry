<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Zone extends Model
{
    use HasUuids, SoftDeletes;

    protected $fillable = [
        'region_id', 'name', 'code',
        'address', 'phone', 'email', 'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    // ---------------------------------------------------------------
    // Relationships
    // ---------------------------------------------------------------

    public function region(): BelongsTo
    {
        return $this->belongsTo(Region::class);
    }

    public function subZones(): HasMany
    {
        return $this->hasMany(SubZone::class);
    }

    public function users(): HasMany
    {
        return $this->hasMany(User::class);
    }

    /**
     * All churches in this zone, reached through Sub-zone.
     */
    public function churches()
    {
        return Church::whereHas('subZone', fn ($q) => $q->where('zone_id', $this->id));
    }

    // ---------------------------------------------------------------
    // Accessors
    // ---------------------------------------------------------------

    public function getSubZonesCountAttribute(): int
    {
        return (int) ($this->attributes['sub_zones_count'] ?? $this->subZones()->count());
    }

    public function getChurchesCountAttribute(): int
    {
        return (int) ($this->attributes['churches_count'] ?? $this->churches()->count());
    }
}
