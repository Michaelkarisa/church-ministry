<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('roles', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique();          // ministry_admin, zone_admin, church_admin
            $table->string('display_name');
            $table->text('description')->nullable();
            $table->unsignedTinyInteger('level');      // 1=ministry, 2=zone, 3=church
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('roles');
    }
};
